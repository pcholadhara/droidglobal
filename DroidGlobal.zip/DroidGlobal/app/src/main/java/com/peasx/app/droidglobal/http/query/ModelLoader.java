package com.peasx.app.droidglobal.http.query;

public interface ModelLoader<T> {
        void run(T t);
}
