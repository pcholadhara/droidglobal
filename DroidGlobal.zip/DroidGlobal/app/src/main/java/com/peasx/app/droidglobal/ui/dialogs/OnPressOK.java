package com.peasx.app.droidglobal.ui.dialogs;

public interface OnPressOK {
    void run();
}
