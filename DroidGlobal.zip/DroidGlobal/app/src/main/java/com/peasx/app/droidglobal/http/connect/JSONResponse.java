package com.peasx.app.droidglobal.http.connect;

public interface JSONResponse {

    String SUCCESS      = "SUCCESS";
    String CONTENTS     = "CONTENTS";
    String ERROR_TAG    = "HTTP_ERROR";
    String JSON_ERROR   = "JSON_ERROR";

}
