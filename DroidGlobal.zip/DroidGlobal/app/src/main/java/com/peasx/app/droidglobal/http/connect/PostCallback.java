package com.peasx.app.droidglobal.http.connect;

public interface PostCallback {
    void onSuccess(String string);
}
