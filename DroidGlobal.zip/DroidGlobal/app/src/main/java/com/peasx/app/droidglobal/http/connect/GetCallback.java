package com.peasx.app.droidglobal.http.connect;


import org.json.JSONObject;

public interface GetCallback {
    void onSuccess(JSONObject object);
}
