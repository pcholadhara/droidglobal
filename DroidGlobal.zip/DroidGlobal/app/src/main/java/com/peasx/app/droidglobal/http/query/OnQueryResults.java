package com.peasx.app.droidglobal.http.query;

import org.json.JSONArray;
import org.json.JSONObject;

public interface OnQueryResults {
    void processArray(JSONArray jsonArray);
}
