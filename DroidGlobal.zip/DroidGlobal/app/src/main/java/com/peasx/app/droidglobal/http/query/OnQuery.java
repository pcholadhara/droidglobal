package com.peasx.app.droidglobal.http.query;

public interface OnQuery{
        void process(String response);
}
