package com.peasx.app.droidglobal.http.connect;

import org.json.JSONObject;

public abstract class ServerCallback implements GetCallback, PostCallback {
    @Override
    public void onSuccess(String string) {

    }

    @Override
    public void onSuccess(JSONObject object) {

    }





}
